/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sust.classnotfound.touristfriend.useful;

/**
 *
 * @author Rownak
 */
public class Config {
    
    public static String SERVER_URL = "http://192.168.2.108:8084/TouristFriend_BackEnd/";
    
}
